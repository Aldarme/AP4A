/*
 *  @Author: NDJAMBA BATOMEN GABRIELLA
 *  @file Humidity.cpp
 *  @Created on: 9 oct. 2022
 *  @Description: Header file of scheduler which is responsible of receiving the data collected either to 
 * read or store it
 */
#include<iostream>
#include<stdlib.h>
#include "Server.hpp"
#pragma once



class Scheduler
{
    protected:
    int t,l,p,h;
    bool m_logact,m_consolact;


    public: 
        Scheduler(); 
        Scheduler (const Scheduler&){} 
        virtual ~Scheduler (){} 
        Scheduler &operator=(const Scheduler&){return *this;} 
        void getinfo();
     
};






