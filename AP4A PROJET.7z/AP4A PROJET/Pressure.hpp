/*
 *  @Author: NDJAMBA BATOMEN GABRIELLA
 *  @file Humidity.cpp
 *  @Created on: 9 oct. 2022
 *  @Description: Implementation file of humidity
 */
#ifndef def_Pressure
#define def_Pressure
#include<iostream>
#include "Sensor.hpp"


class Pressure : public Sensor
{
protected:
  
public:
    Pressure(){}
    virtual~Pressure(){}
    float aleaGenval();
};
 
#endif
