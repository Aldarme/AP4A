/*
 *  @Author: NDJAMBA BATOMEN GABRIELLA
 *  @file Server.hpp
 *  @Created on: 9 oct. 2022
 *  @Description: Header file of class sensor,parent of light,pressure,temperature,humidity
 */
#ifndef def_Sensor
#define def_Sensor
#include<stdlib.h>
#include<string>

class Sensor
{
protected:
	
	virtual float aleaGenval()=0;
public:
	Sensor(){}
	virtual~Sensor(){}
	Sensor(const Sensor &other){}
	float getData();

};
















#endif

