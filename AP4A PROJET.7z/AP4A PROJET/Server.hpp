/*
 *  @Author: NDJAMBA BATOMEN GABRIELLA
 *  @file Humidity.cpp
 *  @Created on: 9 oct. 2022
 *  @Description: header file of server that contains  the attibutes and methods
 * used to either store or read the data
 */
#ifndef def_Server
#define def_Server
#include "Humidity.hpp"
#include "Temperature.hpp"
#include "Light.hpp"
#include "Pressure.hpp"
#include<string>
class Server
{
        protected : 
        bool act;
        char C;
 
        
        public:
        Server(){}
        Server (const Server &s){} 
        virtual~Server (){} 
        Server & operator= (Server&s){return *this;} 
        
        void consoleWrite(std::string fig , int got,std::string unit,bool act);
        void fileWrite(std::string fig , int got,std::string unit,bool act);
        bool m_consolactive(), m_logactive();



};
#endif