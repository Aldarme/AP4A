/*
 *  @Author: NDJAMBA BATOMEN GABRIELLA
 *  @file Light.cpp
 *  @Created on: 9 oct. 2022
 *  @Description: Implementation file of Sensor that is a parent of light,pressure,
 * humidity,temperature and tha contains the methods alegenval to generate random 
 * values and getdata to receive the values generated
 */
#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<random>
#include<iostream>
#include "Sensor.hpp"
using namespace std;


float Sensor::getData(){
  float data=aleaGenval();
  return data;
   
}

