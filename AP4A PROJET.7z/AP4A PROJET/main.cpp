/*
 *  @Author: NDJAMBA BATOMEN GABRIELLA
 *  @file Humidity.cpp
 *  @Created on: 9 oct. 2022
 *  @Description: Implementation file main where we call our funtion getinfo with an object 
 * responsible of executing this function
 */
#include<stdlib.h>
#include<time.h>
#include<random>
#include<iostream>
#include "Sensor.cpp"
#include "Server.cpp"
#include "Scheduler.cpp"
#include "Light.cpp"
#include "Pressure.cpp"
#include "Humidity.cpp"
#include "Temperature.cpp"
using namespace std;

int main()
{
     Scheduler scher;

	 //welcome message
	 
      
        cout<< "Welcome to this server!!"<<endl;
      
        cout<< "Choose what you require"<<endl;
        if (true)
        {
        
            scher.getinfo();
        }
       
    
     return 0;
 }