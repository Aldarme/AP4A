/*
 *  @Author: NDJAMBA BATOMEN GABRIELLA
 *  @file Humidity.cpp
 *  @Created on: 9 oct. 2022
 *  @Description: Implementation file of humidity
 */
#ifndef def_Light
#define def_Light
#include<iostream>
#include "Sensor.hpp"


class Light : public Sensor
{

public:
    Light(){}
    virtual~Light(){}
   float aleaGenval();
};
 

#endif