/*
 *  @Author: NDJAMBA BATOMEN GABRIELLA
 *  @file Pressure.cpp
 *  @Created on: 9 oct. 2022
 *  @Description: Implementation file of pressure that is a child of sensor
 */
#include<iostream>
#include<random>
#include<time.h>
#include "Pressure.hpp"
using namespace std;

//method that generates random values
float Pressure::aleaGenval()
{
 // initialize random seed: 
  srand (time(NULL));

  // generate random number between 10 and 13: 
  float retval = rand() % 13 + 10;
return retval;
}