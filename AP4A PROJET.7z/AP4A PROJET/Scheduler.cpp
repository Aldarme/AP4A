/*
 *  @Author: NDJAMBA BATOMEN GABRIELLA
 *  @file Humidity.cpp
 *  @Created on: 9 oct. 2022
 *  @Description: Implementation file of scheduler which is responsible of receiving the data collected either to 
 * read or store it.This is done by reference using attributes and object created 
 * the method getinfo is responsible for receiving everything. m_consoleact and m_logact are included
 * as parameters of consolewrite and filewrite for later use in the server
 */
#include<iostream>
#include "Scheduler.hpp"
#include "Sensor.hpp"
#include "Server.hpp"
#include "Light.hpp"
#include "Temperature.hpp"
#include "Humidity.hpp"
#include "Pressure.hpp"
using namespace std;

Scheduler:: Scheduler()
{
  Server sr;
  Scheduler sl;
  sl.m_consolact=sr.m_consolactive();
  sl.m_logact=sr.m_logactive();
  
}



void Scheduler::getinfo()
{
  Temperature temp;
    Light lig;
    Pressure pres;
    Humidity hum;
    Sensor *sen;
    Server ser;
    Scheduler sd;
  
sen= &temp ;
t=sen->getData();
sen= &hum ;
h=sen->getData();
sen= &pres ;
p=sen->getData();
sen= &lig ;
l=sen->getData();



ser.consoleWrite("Humudity",h,"%",m_consolact);
ser.consoleWrite("Temperature",t,"°C",m_consolact);
ser.consoleWrite("Pressure",p,"psi",m_consolact);
ser.consoleWrite("Light",l,"/",m_consolact);

ser.fileWrite("Humidity",h,"%",m_logact);
ser.fileWrite("Temperature",t,"°C",m_logact);
ser.fileWrite("Pressure",p,"psi",m_logact);
ser.fileWrite("Light",l,"/",m_logact);


}
