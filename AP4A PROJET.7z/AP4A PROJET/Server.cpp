/*
 *  @Author: NDJAMBA BATOMEN GABRIELLA
 *  @file Server.cpp
 *  @Created on: 9 oct. 2022
 *  @Description: implementation file of class server 
 */
#include<iostream>
#include<string>
#include<stdlib.h>
#include <fstream>
#include "Server.hpp"
#include "Scheduler.hpp"
#include "Sensor.hpp"
#include "Light.hpp"
#include "Temperature.hpp"
#include "Humidity.hpp"
#include "Pressure.hpp"
using namespace std;

Server s;
Scheduler sc;

//Definition of the method that allows us to see the data collected
void Server::consoleWrite(string fig , int got,string unit,bool m_consoleact)
{
	if (m_consoleact==true){
		cout<<fig <<" = " << got << " "<<unit;
	}
}

//Definition of the method that allows us to store the data in log files
void Server::fileWrite(string fig , int got,string unit,bool m_fileact)
{
	 ofstream file("Log"+fig+".txt",ios::out);
    if(m_fileact==true){
	file<<got<<unit ;
	}
}
//method that is used by the user to choose if he wants to see the data or not
bool Server::m_consolactive()
{
    
    cout<<"Are you activating the console?"<<endl ;
    cout<<"Enter ' 1 ' for yes or ' 2 ' for no "<<endl ;
    cin>>C ;
    
    while(true){
       switch (C)
	   {
	   case 1:
	   return true;
		break;
		case 2:
	   return false;
		break;
	   default:
	   cout<<"wrong entry";
		break;
	  
	  }
    }
}
//method that is used so that the user chooses to store the data or not
bool Server::m_logactive()
{
    cout<<"Do you want to store the data?"<<endl ;
    cout<<"Enter ' 1 ' for yes or ' 2 ' for no "<<endl ;
    cin>>C ;


    while (true)
	{
		switch (C)
		{
		case 1:
			return true;
			break;
		case 2:
			return false;
			break;
		default:
		    cout<<"Wrong entry";
			break;
		
        } 
	}
}

